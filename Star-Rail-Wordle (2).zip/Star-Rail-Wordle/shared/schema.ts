import { pgTable, text, serial, boolean, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const dailyWords = pgTable("daily_words", {
  id: serial("id").primaryKey(),
  date: date("date").notNull().unique(), // The date this word is for
  word: text("word").notNull(),
  hint: text("hint"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const insertDailyWordSchema = createInsertSchema(dailyWords).omit({ id: true });

export type DailyWord = typeof dailyWords.$inferSelect;
export type InsertDailyWord = z.infer<typeof insertDailyWordSchema>;

// Schema for updating the daily word
export const updateDailyWordSchema = insertDailyWordSchema.partial();
